This is a project done by me Sahu Chintha a Northwest missouri student as part of my assignment.
I have used Bootstrap, html, css in this project.my partner for this project was anil.

 Homepage: 
   -profile picture
   -video 
   -a breaf discription about me
 your choice:
   -a small form that calculates travel charges for different countries
 contact:
   -a contact form and my emailID.
 about me:
   -lot of information about me.

